import static org.testng.Assert.*;
import org.testng.annotations.*;
import java.util.*;
public class testScript {
    private static Object[][] testData1 = new Object[][] {
            //test      size    matte  quant rush    discount   output
            {"R_11",    "4x6",  false, 1,    false,  "null",    0.14},
            {"R_12",    "5x7",  true,  1,    true,   "null",    1.37},
            {"R_13",    "8x10", true,  1,    false,  "null",    0.72},
            {"R_14",    "5x7",  true,  50,   true,   "null",    19.50},

            {"R_21",    "4x6",  false, 50,   false,  "null",    7.00},
            {"R_22",    "8x10", true,  50,   true,   "null",    35.15},
            {"R_23",    "8x10", false, 50,   false,  "null",    34.00},
            {"R_24",    "5x7",  false, 75,   false,  "null",    24.75},

            {"R_31",    "4x6",  true,  75,   true,   "null",    13.00},
            {"R_32",    "8x10", false, 100,  false,  "null",    61.75},
            {"R_33",    "4x6",  false, 100,  true,   "N56M2",   12.00},
            {"R_34",    "5x7",  true,  75,   true,   "null",    28.50},

            {"R_44",    "4x6",  true,  10,   false,
                        "5x7",  false, 40,   false,  "null",    17.90},
            {"R_45",    "5x7",  false, 40,   false,
                        "8x10", false, 10,   false,  "null",    23.50},
            {"R_46",    "5x7",  false, 50,   false,
                        "5x7",  true,  25,   false,  "N56M2",   30.75},

    };

    @DataProvider(name="dataset1")
    public Object[][] getTestData() {
        return testData1;
    }

    // Method to execute the EP tests
//    @Test(dataProvider="dataset1")
//    public void test_order(String id, String size, boolean matte, int quant, boolean rush, String discount, Double expected)
//    {
//
//        String[] cmdlineinput = {size,Boolean.toString(matte),Integer.toString(quant),Boolean.toString(rush),discount};
//        System.out.println(Arrays.toString(cmdlineinput));
//        assertEquals( Main.main(cmdlineinput),Float.valueOf(String.valueOf(expected)) );
//    }
    @Test(dataProvider="dataset1")
    public void test_order(Object[] args)
    {
//        System.out.println("!");
//        System.out.println((float)args.length/7 == (float) 1);
//        System.out.println("!");
//        System.out.println("-------------------------------------------------");
//        System.out.println(Arrays.toString(args));
        if ((float)args.length/7 == (float) 1){
            String id = (String) args[0];
            String size = (String) args[1];
            boolean matte = Boolean.parseBoolean(args[2].toString());
            int quant = Integer.parseInt(args[3].toString());
            boolean rush = Boolean.parseBoolean(args[4].toString());
            String discount = (String) args[5];
            Float expected = Float.valueOf(String.valueOf(args[6]));
            String[] cmdlineinput = {size,Boolean.toString(matte),Integer.toString(quant),Boolean.toString(rush),discount};
            assertEquals( Main.main(cmdlineinput),Float.valueOf(String.valueOf(expected)) );
        }
        if ((float)args.length/11 == (float) 1){
            String id = (String) args[0];

            String size1 = (String) args[1];
            boolean matte1 = Boolean.parseBoolean(args[2].toString());
            int quant1 = Integer.parseInt(args[3].toString());
            boolean rush1 = Boolean.parseBoolean(args[4].toString());

            String size2 = (String) args[5];
            boolean matte2 = Boolean.parseBoolean(args[6].toString());
            int quant2 = Integer.parseInt(args[7].toString());
            boolean rush2 = Boolean.parseBoolean(args[8].toString());

            String discount = (String) args[9];
            Float expected = Float.valueOf(String.valueOf(args[10]));
            String[] cmdlineinput = {size1,Boolean.toString(matte1),Integer.toString(quant1),Boolean.toString(rush1)
                    ,size2,Boolean.toString(matte2),Integer.toString(quant2),Boolean.toString(rush2), discount};
            assertEquals( Main.main(cmdlineinput),Float.valueOf(String.valueOf(expected)) );
        }


//        String[] cmdlineinput = {size,Boolean.toString(matte),Integer.toString(quant),Boolean.toString(rush),discount};
//        System.out.println(Arrays.toString(cmdlineinput));
//        assertEquals( Main.main(cmdlineinput),Float.valueOf(String.valueOf(expected)) );
    }


}













